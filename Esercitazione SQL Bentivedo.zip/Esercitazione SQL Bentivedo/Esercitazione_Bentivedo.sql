-- TASK 2 DEFINIZIONE STRUTTURE TABELLE
CREATE DATABASE ToysGroup;
USE ToysGroup;

CREATE TABLE Category (
    Category_ID INT PRIMARY KEY,
    Category_Name VARCHAR(255) NOT NULL
);

CREATE TABLE Region (
    Region_ID INT PRIMARY KEY,
    Region_Name VARCHAR(255) NOT NULL
);

CREATE TABLE Product (
    Product_ID INT PRIMARY KEY,
    Category_ID INT,
    Product_Name VARCHAR(255) NOT NULL,
    FOREIGN KEY (Category_ID) REFERENCES Category(Category_ID)
);

CREATE TABLE Country (
    Country_ID INT PRIMARY KEY,
    Region_ID INT,
    Country_Name VARCHAR(255) NOT NULL,
    FOREIGN KEY (Region_ID) REFERENCES Region(Region_ID)
);

CREATE TABLE Sales (
    Sales_ID INT PRIMARY KEY,
    Product_ID INT,
    Country_ID INT,
    Price DECIMAL(10, 2),
    OrderDate DATE,
    Quantity INT,
    FOREIGN KEY (Product_ID) REFERENCES Product(Product_ID),
    FOREIGN KEY (Country_ID) REFERENCES Country(Country_ID)
);
-- TASK 3 POPOLAMENTO TABELLE
INSERT INTO Category (Category_ID, Category_Name) VALUES
(1, 'Action Figures'),
(2, 'Arts and Crafts'),
(3, 'Board Games'),
(4, 'Dolls'),
(5, 'Electronic Toys'),
(6, 'Marvel Toys'),
(7, 'Barbie Dolls'),
(8, 'Educational Toys'),
(9, 'Outdoor and Sports Toys'),
(10, 'Building Toys');

INSERT INTO Region (Region_ID, Region_Name) VALUES
(1, 'North America'),
(2, 'South America'),
(3, 'Europe'),
(4, 'Africa'),
(5, 'Asia'),
(6, 'Oceania'),
(7, 'Antarctica'),
(8, 'Middle East'),
(9, 'Central America'),
(10, 'Caribbean'),
(11, 'Western Europe'),
(12, 'Eastern Europe'),
(13, 'Northern Europe'),
(14, 'Southern Europe');

INSERT INTO Product (Product_ID, Category_ID, Product_Name) VALUES
(1, 1, 'Marvel Legends Series'),
(2, 2, 'Play-Doh Sets'),
(3, 2, 'Crayola Art and Craft Kits'),
(4, 3, 'Monopoly'),
(5, 3, 'Scrabble'),
(6, 3, 'Scrabble Board Game'),
(7, 4, 'American Girl Dolls'),
(8, 4, 'L.O.L.'),
(9, 5, 'Fisher-Price Laugh & Learn'),
(10, 5, 'VTech Smart Start'),
(11, 6, 'Marvel Minimates'),
(12, 6, 'Marvel Avengers Series'),
(13, 6, 'Iron Man Action Figure'),
(14, 7, 'Barbie Dreamhouse'),
(15, 7, 'Barbie Career Dolls'),
(16, 7, 'Barbie Fashionista Dolls'),
(17, 8, 'Osmo - Genius Kit'),
(18, 8, 'VTech Touch and Learn'),
(19, 9, 'Nerf Blasters'),
(20, 10, 'LEGO Classic Sets');

-- Inserimento dei vari dati nella tabella Country
INSERT INTO Country (Country_ID, Region_ID, Country_Name) VALUES
(1, 3, 'Italy'),
(2, 1, 'USA'),
(3, 1, 'Canada'),
(4, 2, 'Brazil'),
(5, 11, 'Germany'),
(6, 5,'Japan'),
(7, 6, 'Australia'),
(8, 5, 'India'),
(9, 4, 'South Africa'),
(10, 11, 'France');

INSERT INTO Sales (Sales_ID, Product_ID, Country_ID, SalesAmount, OrderDate, Quantity) VALUES
(1, 1, 1, 34.99, '2025-01-20', 60), 
(2, 2, 2, 44.99, '2024-11-21', 50), 
(3, 3, 3, 84.99, '2024-10-25', 40), 
(19, 3, 4, 84.99, '2025-02-15', 25), 
(4, 4, 4, 109.99, '2024-09-30', 30), 
(5, 5, 5, 34.99, '2024-08-22', 110),
(6, 6, 1, 49.99, '2024-12-10', 70), 
(7, 7, 2, 59.99, '2024-11-01', 45), 
(8, 8, 3, 69.99, '2024-10-18', 35), 
(20, 8, 4, 69.99, '2025-03-05', 28);

-- TASK 4 -- ESERCIZIO 1

SELECT Product_ID, COUNT(*) 
FROM Product
GROUP BY Product_ID
HAVING COUNT(*) > 1;

SELECT Category_ID, COUNT(*) 
FROM Category
GROUP BY Category_ID
HAVING COUNT(*) > 1;

SELECT Region_ID, COUNT(*) 
FROM Region
GROUP BY Region_ID
HAVING COUNT(*) > 1;

SELECT Country_ID, COUNT(*) 
FROM Country
GROUP BY Country_ID
HAVING COUNT(*) > 1;

SELECT Sales_ID, COUNT(*) 
FROM Sales
GROUP BY Sales_ID
HAVING COUNT(*) > 1;

-- ESERCIZIO 2
SELECT
    s.Sales_ID AS CodiceDocumento,
    s.OrderDate AS Data,
    p.Product_Name AS Prodotto,
    c.Category_Name AS Categoria,
    co.Country_Name AS Stato,
    r.Region_Name AS Regione,
    CASE 
        WHEN DATEDIFF(CURDATE(), OrderDate) > 180 THEN 'True'
        ELSE 'False'
    END AS PiùDi180Giorni
FROM Sales s
INNER JOIN Product p ON s.Product_ID = p.Product_ID
INNER JOIN Category c ON p.Category_ID = c.Category_ID
INNER JOIN Country co ON s.Country_ID = co.Country_ID
INNER JOIN Region r ON co.Region_ID = r.Region_ID;

-- ESERCIZIO 3
SELECT 
	Product_ID,
	SUM(Quantity) AS TotaleQuantità
FROM Sales
WHERE OrderDate BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND CURDATE()
GROUP BY Product_ID
HAVING TotaleQuantità > (SELECT AVG(quantity) FROM sales);

-- ESERCIZO 4 
SELECT
	Product_Name AS Prodotto,
	s.Product_ID AS CodiceProdotto,
	SUM(SalesAmount) AS FatturatoTotale,
    YEAR(s.OrderDate) AS Anno
FROM Sales s 
LEFT JOIN Product p ON s.Product_ID = p.Product_ID
GROUP BY s.Product_ID, YEAR(s.OrderDate), Product_Name
ORDER BY Anno DESC, FatturatoTotale DESC;

-- ESERCIZIO 5
SELECT
	SUM(SalesAmount) AS FatturatoTotale,
    YEAR(s.OrderDate) AS Anno,
    Country_Name AS Stato
FROM Sales s
INNER JOIN Country c ON	s.Country_ID = c.Country_ID
GROUP BY Country_Name, YEAR(s.OrderDate)
ORDER BY Anno DESC, FatturatoTotale DESC;

-- ESERCIZIO 6
SELECT 
	Category_Name ,
	SUM(SalesAmount) AS FatturatoTotale
FROM Sales s
INNER JOIN Product p ON p.Product_ID = s.Product_ID
INNER JOIN Category c ON c.Category_ID = p.Category_ID
GROUP BY Category_Name
ORDER BY  FatturatoTotale DESC LIMIT 1;

-- ESERCIZIO 7
SELECT
	Product_Name AS Prodotto,
    p.Product_ID AS CodiceProdotto
FROM Product p
LEFT JOIN  Sales s ON s.Product_ID = p.Product_ID
WHERE SalesAmount IS NULL;

SELECT p.Product_ID, p.Product_Name
FROM Product p
WHERE p.Product_ID NOT IN (SELECT s.Product_ID FROM Sales s);

-- ESERCIZIO 8

CREATE VIEW VersioneDenormalizzata AS
SELECT 
    p.Product_ID AS CodiceProdotto,
    p.Product_Name AS NomeProdotto,
    c.Category_Name AS NomeCategoria
FROM Product p
INNER JOIN Category c ON p.Category_ID = c.Category_ID;

-- ESERCIZIO 9 
CREATE VIEW GeoInfo AS
SELECT
    r.Region_Name AS AreaGeografica,
    c.Country_Name AS Stato
FROM
    Region r
JOIN
    Country c ON r.Region_ID = c.Region_ID;